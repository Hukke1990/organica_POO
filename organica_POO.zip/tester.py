import menuProductos
import menuCliente
import menuProveedores
import menuUsuario
from colorama import Fore, Back, Style
from datetime import datetime
import platform
import os


def current_date_format(date):
    months = ("Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio",
              "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre")
    day = date.day
    month = months[date.month - 1]
    year = date.year
    messsage = "{} de {} del {}".format(day, month, year)

    return messsage


now = datetime.now()


def limpiarPantalla():  # limpiar la consola completa
    sistema_operativo = platform.system()
    if sistema_operativo == "Windows":
        os.system("cls")
    else:
        os.system("clear")


class MenuOrganica:

    def main(self):
        limpiarPantalla()
        print(f'{Fore.CYAN}BIENVENIDOS A ORGANICA{Fore.RESET}')
        print(f'Para poder utilizar esta aplicacion debe conectarse con su cuenta\n')
        print(f'1: Conectarse')
        print(f'2: Registrarse')

        while True:
            opcion = input(f'>> ')

            if opcion == '1':
                menuUsuario.MenuUsuario.conectarse(self)
            elif opcion == '2':
                menuUsuario.MenuUsuario.registrarse(self)
            else:
                print(f'Opcion invalida!')

        print(f'\n{Fore.CYAN}By Hukke.Software{Fore.RESET}')

    def menuPrincial(self):
        while True:
            limpiarPantalla()
            print(current_date_format(now))
            print(f'{Fore.CYAN}MENU PRINCIPAL{Fore.RESET}')
            print(f'1. Menu Clientes')
            print(f'2. Menu Productos')
            print(f'3. Menu Proveedores')
            print(f'4. Menu Ventas\n')

            opcion = input(f'Ingrese una opcion: ')

            if opcion.isdigit():
                if opcion == '1':
                    self.menuClientes()
                elif opcion == '2':
                    self.menuProductos()
                elif opcion == '3':
                    self.menuProveedores()
                elif opcion == '4':
                    pass

    def menuClientes(self):
        while True:
            limpiarPantalla()
            print(f'{Fore.CYAN}MENU CLIENTES{Fore.RESET}')
            print(f'1: Ver Clientes')
            print(f'2: Buscar Cliente')
            print(f'3: Agrega Cliente')
            print(f'4: Menu Principal')
            opcion = input(f'Ingrese una opcion: ')

            if opcion == '1':
                menuCliente.MenuCliente.verClientes()
            elif opcion == '2':
                menuCliente.MenuCliente.buscarClientes(self)
            elif opcion == '3':
                menuCliente.MenuCliente.agregarClientes(self)
            elif opcion == '4':
                self.main()

    def menuProductos(self):
        while True:
            limpiarPantalla()
            print(f'{Fore.CYAN}MENU PRODUCTOS{Fore.RESET}')
            print(f'1: Ver Productos')
            print(f'2: Buscar Producto')
            print(f'3: Agrega Producto')
            print(f'4: Modificar precios generales')
            print(f'5: Menu Principal')
            opcion = input(f'Ingrese una opcion: ')

            if opcion == '1':
                menuProductos.MenuProductos.verProductos()
            elif opcion == '2':
                menuProductos.MenuProductos.buscarProducto(self)
            elif opcion == '3':
                menuProductos.MenuProductos.agregarProductos(self)
            elif opcion == '4':
                menuProductos.MenuProductos.modificarPrecio()
            elif opcion == '5':
                self.main()

    def menuProveedores(self):
        while True:
            limpiarPantalla()
            print(f'{Fore.CYAN}MENU PROVEEDORES{Fore.RESET}')
            print(f'1: Ver Proveedores')
            print(f'2: Buscar Proveedor')
            print(f'3: Agrega Proveedor')
            print(f'4: Menu Principal')
            opcion = input(f'Ingrese una opcion: ')

            if opcion == '1':
                menuProveedores.MenuProveedor.verProveedores()
            elif opcion == '2':
                menuProveedores.MenuProveedor.buscarProveedores(self)
            elif opcion == '3':
                menuProveedores.MenuProveedor.agregarProvedores(self)
            elif opcion == '4':
                self.main()

    # '''
    # Agregar productos
    '''galletitas = productos.Productos('P00011',
                    'Galletitas Surtidas',
                    'Galletitas dulces',
                    440.0, 'Alimentos',
                    'Vida sana',
                    '26/06/2023',
                    24)'''

    '''galletitas = productos.Productos(0, "", "", 0, "", "", "", 0)
    idProducto = galletitas.establecerIdProducto()
    nombre = galletitas.establecerNombreProducto()
    descripcion = galletitas.establecerDescripcionProducto()
    precio = galletitas.establecerPrecioProducto()
    categoria = galletitas.establecerCategoriaProducto()
    proveedor = galletitas.establecerProveedor()
    fecha = galletitas.establecerFecha()
    cantidadDisponible = galletitas.establecerCantidadDisponible()
    #galletitas.establecerFecha()

    galletitas.agregarProductoCompleto(galletitas.obtenerNombreProducto(),
                                       galletitas.obtenerDescripcionProducto(),
                                       galletitas.obtenerPrecioProducto(),
                                       galletitas.obtenerCategoriaProducto(),
                                       galletitas.obtenerProveedor(),
                                       galletitas.obtenerFecha(),
                                       galletitas.obtenerCantidadDisponible())'''

    # Agregar Clientes
    '''cliente = clientes.Cliente('Monica Silvana',
                               'Lezcano',
                               'Concepcion del Uruguay',
                               'Artusi 187',
                               '3442608040',
                               'monicalezcano79@gmail.com')
    cliente.establecerIdCliente()'''

    '''cliente = clientes.Cliente(0, "", "", "", "", "")
    idCliente = cliente.establecerIdCliente()
    nombre = cliente.establecerNombreCliente()
    apellido = cliente.establecerApellidoCliente()
    ciudad = cliente.establecerCiudadCliente()
    direcc = cliente.establecerDireccionCliente()
    tel = cliente.establecerTelefonoCliente()
    email = cliente.establecerEmailCliente()

    cliente.agregarClienteCompleto(cliente.obtenerNombreCliente(),
                                    cliente.obtenerApellidoCliente(),
                                    cliente.obtenerCiudadCliene(),
                                    cliente.obtenerDireccionCliente(),
                                    cliente.obtenerTelefonoCliente(),
                                    cliente.obtenerEmailCliente())

    
    
    

    #Imprimir Datos
    print(productos.Productos.__str__(galletitas))
    print(clientes.Cliente.__str__(cliente))'''
    # '''


if __name__ == '__main__':
    test = MenuOrganica()
    test.main()
